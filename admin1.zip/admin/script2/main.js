


// navigation menu toggle function
$(function(){
	$("#sidebarCollapse").on("click",function(){
		$('#sidebar,#content').toggleClass('active');
	});
});

// dismis alert pop -up
// var alertList = document.querySelectorAll('.alert');
// alertList.forEach(function (alert) {
//   new bootstrap.Alert(alert);
// });

// var alertNode = document.querySelector('.alert')
// var alert = bootstrap.Alert.getInstance(alertNode)
// alert.close()


            

