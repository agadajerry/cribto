<?php include ('config/users_data.php');
 
if(!isset($_SESSION["admin_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body>
    
    <!-- vertical menu -->

     <?php include 'header.php'?>
        <!-- Page Content  -->
     <div id="content" class="p-4 p-md-5 pt-5 page-content">
       <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->

         <!-- Make withdrawals -->

         <div class="row">
          <div class="col-md-6">
            <div class="bg-white mb-3">
              <p class="py-1 px-3" style="color:#003;">Add investment</p>
               <?php 

              if (!empty($reg_msg)) {
                $class = "alert  ";
                $role ="alert";
               echo "<div role= '$role' class='$class $reg_class' id='alert-dismissible'>". $reg_msg;
               echo "</div>";
                
              }
              ?>
            </div>
            <div class="card">
        <ul class="list-group list-group-flush">
          <li class="list-group-item bg-white">
            <div class="bg-primary mb-3">

               <?php
           if(isset($_SESSION['investor_email'])){
              
            echo "<p class='py-4 px-3' style='color:white;'> Add investment for ".$_SESSION['investor_name'].'</p>';
            }
            ?>
            </div>
            <p></p>
          </li>
          <li class="list-group-item">
          

        <form method="post">
              <div class="mb-3">
            <label for="amount" class="form-label"><h3>Amount</h3></label>
              <input type="number" class="form-control" id="amount" name="amount">
            </div>
            <div class="mb-4">
            <label for="plans" class="form-label"><h3>Investment plans</h3></label>
              <select class="form-select" id="plans" name="plan_option">
                <option selected>Select plan</option>
               
                <?php

            if (isset($_SESSION['admin_name'])) {
              
             $result = mysqli_query($GLOBALS['conn'],"Select DISTINCT plan_name from investment_plan GROUP BY plan_name");
              
              if (mysqli_num_rows($result)>0) {
    
            while ($row = mysqli_fetch_array($result)){
              
              echo " <option >".$row['plan_name']."</option>";
             
            }
            }
            }

          ?>
              </select>
            </div>
          <button type="submit" class="btn btn-primary mb-4" name= 'submit_plan'>Submit</button>
      </form>

          </li> 
        </ul>
      </div>
        </div>
        <div class="col-md-3"></div>
        </div>
       </div>
     </div>
       
 </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>
    <script >
       $(document).ready(function() {
    $('#investment_table').DataTable();
} );
    </script>
  </body>
</html>