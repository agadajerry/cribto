<?php include ('config/users_data.php');
 
if(!isset($_SESSION["admin_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body  style="background: #ccc;">
    
    <!-- vertical menu -->

   <?php include 'header.php'?>

        <!-- Page Content  -->
     <div id="content" class="p-4 p-md-5 pt-5 page-content">
       <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
          <div class="row">
            <div class="col-md-2"></div>
             <div class="col-md-8">
               <!-- card for holder user details -->
               <div class="card">
                <div class="card-body">
                  
                      <div class="row">
                        <div class="col-md-2"></div>
                      <div class="col-md-8" >
                        <h3 class="text-center" style="color:green">User Messages</h3>
                        <div style="border: 1px solid #ccc; border-radius:3px; padding: 5px;" class="overflow-scroll">
                          
                          <?php if(!empty('admin_name')){
                               $result = userMessage();
                                if ($result) {
                                  while($row = mysqli_fetch_array($result)){
                                     $email = $row['email'];
                                     $message = $row['message'];

                                     echo "<h6 style= 'border:1px solid #ccc; border-radius:10px; background: #003; color: #fff; text-align: center; padding:5px; font-size: 12px;'>".$email."</h6>";

                                     echo "<p style='border-bottom-right-radius: 30px; border:1px solid #ccc; padding: 10px; color:#fff' class=bg-success>".$message."</p>";
                                  }
                                }
                          }
                          ?> 
                      </div> 
              </div>
               <div class="col-md-2"></div>
            </div>
             </div>
             
          </div>
       
 </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>
  </body>
</html>