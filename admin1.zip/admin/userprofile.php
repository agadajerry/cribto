<?php include ('config/users_data.php');
 
if(!isset($_SESSION["admin_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body>
    
    <!-- vertical menu -->

   <?php include 'header.php'?>

        <!-- Page Content  -->
     <div id="content" class="p-4 p-md-5 pt-5 page-content">
       <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
          <div class="row">
            <div class="col-md-2"></div>
             <div class="col-md-8">
               <!-- card for holder user details -->
               <div class="card">
                <div class="card-body">
                <div class="card">
                  <?php if(!empty($user_name)):?>
                <img src="plan_images/<?php echo $user_image;?>" class="card-img-top mx-auto my-1" style = "width:150px; height:150px; 
                border-radius:50%;" alt="admin image">
                
                <h6 class="text-center mt-2"> <i class="fa fa-user"></i> <?php echo $user_name; ?></h6>

                <div class="card-body">
                  <h5 class="card-title">Profile
                  <span style="width:100%;background: #ccc;
                               height: 2px; border:1px solid blaack;margin-top:10px; display: block; "></span></h5>
                  <h6> <i class="fa fa-user"></i> Admin</h6>
                  <h6> <i class="fa fa-envelope"></i> <?php echo $_SESSION['admin_email']?></h6>
                  <h6> <i class="fa fa-clock"></i> <?php echo 'Last Login: '.$last_login; ?></h6>

                </div>
              </div>
            <?php endif;?>
              <h3 class="text-center mt-1">Edit Profiles</h3>
              <?php if(!empty($upload_msg)):?>
                  <div class=" alert alert-dismissible fade show <?php echo $scss_class;?>" role="alert"> <?php echo $upload_msg; ?></div>
                <?php  endif;?>
                </div>
                <ul class="list-group list-group-flush">
                  <li class="list-group-item">
                    <form method="post" action="userprofile.php" enctype="multipart/form-data">
                      <div class="col-md-6">
                      <div class="mb-3">
                      <label for="name"  class ="form-label">Name</label>
                      <input type="text" name="name" class="form-control" id="name" autocomplete="false">
                      </div>
                      </div>
                      <div class="col-md-6">
                      <div class="mb-3">
                      <label for="password"  class ="form-label">New Password</label>
                      <input type="password" name="password" class="form-control" id="password">
                      </div>
                      </div>
                      <div class="col-6">
                      <div class="mb-3">
                      <label for="password2" class="form-label">Repeat Password</label>
                      <input type="password" name="password2" class="form-control" id="password2">
                      </div>
                    </div>
                       <div class="mb-3">
                      <label for="password2" class="form-label">Change Profile Picture</label>
                      <input type="file" name="profile_image" class="form-control" id="profile_image">
                      </div>
                      <button class="btn btn-success" name="update_profile">Update</button>
                    </form>
                  </li>
                  
                </ul>
                
              </div>
             </div>
              <div class="col-md-2"></div>
          </div>
       
 </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>

    
  </body>
</html>