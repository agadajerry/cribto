<?php include ('config/users_data.php');
 
if(!isset($_SESSION["admin_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body>
    
    <!-- vertical menu -->

    <?php include 'header.php'?>

        <!-- Page Content  -->
     <div id="content" class="p-4 p-md-5 pt-5 page-content">
       <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
        <h3 class="mb-4"> Edit Investment plans</h3>
         
        <?php  if(!empty($upload_msg)):?>
              
             <div class=" col-md-6 alert <?php echo $scss_class; ?>"><?php echo $upload_msg;?></div>
            


            <?php  endif; ?>
           
        <!-- d-flex justify-content-around -->
        <div class="card border-dark mb-3 col-md-6">
          <div class="card-header bg-primary text-white"><h3>Plans Details</h3></div>
          <div class="card-body text-secondary">
        <form method="post" action="Edit_plans.php" enctype="multipart/form-data">
            <div class="mb-3">
            <label for="plan_name" class="form-label"><h5 style="color:#002">Plan Name</h5></label>
            <input type="text" class="form-control" id="plan_name" name="plan_name"  value="<?php echo $_SESSION['plan_name'];?>">
          </div>
          <div class="d-flex justify-content-around">
            <div class="mb-3">
            <label for="min_deposit" class="form-label"><h5 style="color:#002">Min Deposit</h5></label>
            <input type="number" class="form-control" id="min_deposit" name="min_deposit" value="<?php echo $min_deposit;?>">
          </div>
          <div class="mb-3">
            <label for="max_deposit" class="form-label"><h5 style="color:#002">Max Deposit</h5></label>
            <input type="number" class="form-control" id="max_deposit" name="max_deposit" value="<?php echo $max_deposit;?>">
          </div>
          </div>
          <div class="d-flex justify-content-around">
            <div class="mb-3">
            <label for="return_freq" class="form-label"><h5 style="color:#002">Return Frequency</h5></label>
            <select class="form-select" aria-label="Default select example" name="return_freq">
            <option selected>Daily</option>
            <option >Weekly</option>
            <option >Monthly</option>
            <option >Yearly</option>
          </select>
          </div>
          <div class="mb-3">
            <label for="return_percentage" class="form-label"><h5 style="color:#002">Return rate/Percentage</h5></label>
            <input type="number" class="form-control" id="return_percentage" name="return_percentage"
             value="<?php echo $return_percentage;?>">
          </div>
          </div>
            <div class="mb-3">
            <label for="invest_duration" class="form-label"><h5 style="color:#002">Duration</h5></label>
            <input type="number" class="form-control" id="invest_duration" name="invest_duration"
            value="<?php echo $invest_duration;?>">
          </div>
          <div class="mb-3">
            <label for="plan_image" class="form-label"><h5 style="color:#002">Image</h5></label>
            <div class="input-group mb-3">
            <input type="file" class="form-control" placeholder="No file selected" name="image">
            </div>
          </div>
          <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-primary" name="update-plan">Update</button>
          <button type="submit" class="btn btn-primary" name="delete-plan">Delete Plan</button>
          </div>
      </form>
      </div>
        </div>
       
  </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>
    <script >
       $(document).ready(function() {
    $('#investment_table').DataTable();
} );
    </script>
  </body>
</html>