<?php include ('config/users_data.php');
 
if(!isset($_SESSION["admin_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
  </head>
  <body>
    
    <!-- vertical menu -->

     <?php include 'header.php'?>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5 page-content">
        <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
        <h2 class="mb-4">Dashboard</h2>
        
        <!-- cards hold menu information -->
      <div class="row">
      <div class="col-md-3">
        <div class="card first-card-bg">
          <div class="card-body">
           
            <?php if(isset($_SESSION['admin_name'])):?>
               <h5 class="card-title"><?php echo $count;?></h5>
             <?php endif;?>
            <p class="card-text">Users</p>
            <div class="d-flex justify-content-around">
                   <button type="submit" name="button" class="btn btn-secondary btn-sm bonus-btn" data-toggle="modal"
                   data-target="#staticBackdrop">Reset Bonus</button>
                  <a href="users.php" class="btn btn-primary">More Info</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card second-card-bg">
          <div class="card-body">
            <?php if(isset($_SESSION['admin_name'])):?>
              <h5 class="card-title">$ <?php echo $sumAllInvestment; ?></h5>
            <?php endif;?>
            <p class="card-text">Investment</p>
            <a href="investment.php" class="btn btn-primary">More Info</a>
          </div>
        </div>
      </div>
      <div class="col-md-3 ">
        <div class="card">
          <div class="card-body third-card-bg">
            <h5 class="card-title">$174390</h5>
            <p class="card-text">Payments</p>
            <a href="#" class="btn btn-primary">More info</a>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <div class="card-body fourth-card-bg">
            <h5 class="card-title">$121540</h5>
            <p class="card-text">Withdraws</p>
            <a href="#" class="btn btn-primary">More info</a>
          </div>
        </div>
      </div>
    </div>
    <!-- end of cards -->

    <!-- investment selection section -->

    <h2 class="mb-4 mt-3">Invest</h2>
            
            <!-- cards hold menu information -->
      <div class="row">

      <!-- get plan from database, investmentplan -->
      <?php  if (isset($_SESSION['admin_name'])):?>
            
              
           <?php   $result = selectAllPlan();?>

          <?php  if (mysqli_num_rows($result)>0):?>

           <?php while ($row = mysqli_fetch_array($result)):?>

            <div class="col-md-4 shadow p-3 mb-5 bg-white rounded">
            <div class="card ">
              <div class="card-header" style="background:#ad08f8; color:#fff;">
                <h3 class="text-center"><?php echo $row['plan_name'];?></h3>
                <h1 class="text-center"><?php echo $row['return_percent']; ?>%</h1>
              </div>
              <ul class="list-group list-group-flush">
                <li class="list-group-item"><?php echo 'Daily for ' .$row['duration'].' Days'; ?></li>
                <li class="list-group-item"><?php echo 'Total Profit % '.$row['return_percent']*$row['duration']; ?></li>
                <li class="list-group-item"><?php echo 'Minimum Deposit ' .$row['min_deposit'].'$'; ?></li>
                <li class="list-group-item"><?php echo 'Maximum Deposit ' .$row['max_deposit'].'$'; ?></li>
              </ul>
                </div>
              </div>
        
      <?php endwhile;?>
        <?php endif;?>
        <?php endif;?>

     <!-- modal body for resetting  registration bonus -->
    
    <div class="modal fade" id="staticBackdrop" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">UPDATE BONUS</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

      <?php if(!empty($upload_msg)):?>

        <div  role="alert" class= "alert <?php echo $scss_class;?>">
          <?php echo $upload_msg; ?>
        </div>
      <?php endif;?>

 <form method="POST">
    <label for="bonusamount" class="form-label">Bonus Amount</label>
    <input type="number" class="form-control" id="bonusamount" name="bonus" value="<?php echo $bonusVal; ?>">
    <button type="submit" class="btn btn-primary btn mt-3" name="update-bonus">Update</button>
</form>
<!-- ################################################################# -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" id="dismissModal">Close</button>
      </div>
    </div>
  </div>
</div>

</div>
   <!-- end of content container-->


 </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>

    <!-- script>
      

      //   $('.bonus-btn').on('click',function(){

      //    $('#bonusModal').modal('show');
       
      // })
  //          $(document).ready(function(){

  //     $('#dismissModal').on('click',function(){
  //    $('#bonusModal').hide();
  // })
  //      })

    </script> -->
  </body>
</html>