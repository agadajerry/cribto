<?php include ('config/users_data.php');
 
if(!isset($_SESSION["admin_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body>
    
    <!-- vertical menu -->

    <?php include 'header.php'?>

        <!-- Page Content  -->
     <div id="content" class="p-4 p-md-5 pt-5 page-content">
       <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
        <h3 class="mb-4"> Update Investment Time</h3>
         
           
        <!-- d-flex justify-content-around -->
        <div class="card border-dark mb-3 col-md-6">
            <div class="card-header bg-primary text-white"><h3>Update amount for <?php echo $userName;?></h3></div>
            <div class="card-body text-secondary">
              <?php if (!empty($upload_msg)) :?>
            <div class=" alert <?php echo  $scss_class;?>" role="alert">
              <?php echo $upload_msg; ?>
              </div>
              <?php endif;?>

              <p class="card-text"> Running Day(s) <?php echo ' : '.$days;?></p>
              <form method="POST">
                <button type ='submit' class="btn btn-success" name="update_amount">Update amount</button>&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="#" class="btn btn-danger">Delete User</a>
              </form>
           </div>
        </div>
       
  </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>
  </body>
</html>