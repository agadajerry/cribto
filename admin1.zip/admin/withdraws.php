<?php include ('config/users_data.php');
 
if(!isset($_SESSION["admin_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body>
    
    <!-- vertical menu -->

     <?php include 'header.php'?>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5 page-content">
        <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
        <h2 class="mb-4">Withdraws</h2>

  <!-- table of widthrawals -->
  <table class="table mt-4 table-striped" id="withdraw_table">
    <div class="d-flex justify-content-between mb-4">
      <p>My Withdraws</p> 
      <span><a href="make_withdraw.html" class="btn btn-primary">Make a Withdraws</a></span>
    </div>
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Amount</th>
      <th scope="col">Users</th>
      <th scope="col">Status</th>
      <th scope="col">Address</th>
      <th scope="col"> Hash</th>
      <th scope="col">Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>$32,999</td>
      <td>John Doe</td>
      <td>Successs</td>
      <td>547jdkvjdfkdjf7f9dkdk8454fkdjfr</td>
      <td>ffdfdggffgff</td>
      <td>12/07/2021</td>
    </tr>
    <tr>
      <td>2</td>
      <td>$42,999</td>
      <td>Jane Doe</td>
      <td>Faied</td>
      <td>547jdkvjdfkdjf7f9dkdk8454fkdjfr</td>
      <td>ytytytyttytyghgfd</td>
      <td>12/07/2020</td>
    </tr>
  </tbody>
</table>
</div>

      
   <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>
    <script>
      $(document).ready(function() {
    $('#withdraw_table').DataTable();
} );
    </script>
  </body>
</html>