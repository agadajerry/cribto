<?php 
 
session_start(); 
include 'config/dbConnect.php';
    
    // global variables
    $upload_msg="";
    $reg_msg="";
    $reg_class="";
    $scss_class="";
   
	$my_con =  new DbConnection();
 	$conn = $my_con->connect();



 
 if (isset($_POST['logout'])) {
 	 		header("location: login.php");
			// session_destroy();
 }

 //insert  investment plan
 

//get data from field
 if (isset($_POST['submit'])) {

 	$fullname = getInputData("fullname");
 	$email = getInputData("email");
 	$password = md5(getInputData("password"));
    $date =  date('y-m-d H:i:s');


 		$select_user = "SELECT * FROM admin_info where email = '".$email."'";

 		$result = mysqli_query($GLOBALS['conn'], $select_user);

 		if (mysqli_num_rows($result)>0){

            $reg_msg ='The email you are trying to used already exist';
            $reg_class ="alert-danger";			
 			
 		}else{
 	if ($fullname && $email && $password) {
	$qry  ="INSERT INTO admin_info (id,full_name,email, password,image,last_login) values(
 	'','$fullname','$email','$password','admin.png','$date')";

 	if (mysqli_query($GLOBALS['conn'],$qry)) {

 		   $_SESSION['admin_email']= $email;
           $_SESSION['admin_name']= $fullname;

 		header("location: index.php");
 	}
 }else{
 	          $reg_msg='Admin info not inserted.Database error.';
            $reg_class="alert-danger";     
 }

}
}

// login section 
    // $email =''

    if (isset($_POST['login'])) {
 
 	$email = getInputData("email");
 	$password = md5(getInputData("password"));



 		$select_user = "SELECT * FROM admin_info where email = '".$email."' AND password = '".$password."'";

 		$result = mysqli_query($GLOBALS['conn'], $select_user);

 		if (mysqli_num_rows($result)==0){


             $reg_msg ='The login information is incorrect. Ensure you use correct login information.';
            $reg_class ="alert-danger";     	
 			
 		}else{

      if (mysqli_num_rows($result)>0) {
    
           while ($row= mysqli_fetch_array($result)){

             $my_name = $row['full_name'];

           }

 				 
                 //update last login date for each login
        
        $date =  date('y-m-d H:i:s');
        $lastLoginQry = "UPDATE admin_info SET last_login = '$date' WHERE email='$email'";
        if (mysqli_query($GLOBALS['conn'],$lastLoginQry)) {

            
        }else{
            echo "error".mysqli_error($GLOBALS['conn']);
        }
        // session login info
           $_SESSION['admin_email']= $email;
            $_SESSION['admin_name']= $my_name;
             header("location:index.php");  

}

        
}
}


 function getInputData($textvalue)
 {
 	$inputText  = mysqli_real_escape_string($GLOBALS['conn'],trim($_POST[$textvalue]));

 	if(empty($inputText)){
 		return false;
 	}else{
 		return $inputText;
 	}
 }


 function actionMsg($class,$msg)
 {
 	$msg = "<h6 class ='$class'>$msg</h6>";

 	echo $msg;
 }

 

 //insert users during register

 function insertUser(){

  $qry = "SELECT * FROM users";

  $result = mysqli_query($GLOBALS['conn'],$qry);

  return $result;
 }

 if (isset($_POST['submit_plan'])) {
 	// <!-- insert investment plant int database table -->
 		$my_name= $_SESSION['investor_name'];
	 	$amount = getInputData("amount");
	 	$plan_option = getInputData("plan_option");
	 	$date =  date('y-m-d');
	 	$email = $_SESSION['investor_email'];


        if (isset($_POST['submit_plan'])) {
         
         if ($amount && $plan_option) {

         $qry = "INSERT INTO investments(id, amount,plan, user, email, status, date)
                         VALUES('','$amount','$plan_option','$my_name',
         '$email','Running','$date')";
         $qry2 = "INSERT INTO payment VALUES('','$amount','$plan_option','$my_name','$email','success','jsd7sdsdnsd89898djskjdkd6', '',
         '$date')";

         $result = mysqli_query($GLOBALS['conn'],$qry);
         $result2 = mysqli_query($GLOBALS['conn'],$qry2);
         if (!$result) {
         	echo "error on investment".mysqli_error($GLOBALS['conn']);
         }
          if (!$result2) {
         	echo "error 2 on payment".mysqli_error($GLOBALS['conn']);
         }
            $reg_msg ='Investment added successfully...';
            $reg_class ="alert-success";  
             $plan_name ='';
             $plan_option='';
             $amount='';

        
        }else{
        	$reg_msg ='investment not made...';
            $reg_class ="alert-danger";  
        }

   }
            // <!-- end of investment plan insertion -->
 }

 // seect from investment table

 function select_investor(){

 	$qry =" select * from investments";
 	$result = mysqli_query($GLOBALS['conn'], $qry);


 	return $result;
 }

 // seect from investment table

 function select_payment(){

 	$qry =" select * from payment";
 	$result = mysqli_query($GLOBALS['conn'], $qry);

 	
 	return $result;
 }

 if (isset($_SESSION['admin_name'])) {
 	select_investor();
 	select_payment();
 }




 //select a particular user from user table before adding his investment to the table of investors

if (isset($_GET['edit'])) {
	select_user_from_investment_tb();
}

 function select_user_from_investment_tb(){
 	 

	 	if (isset($_GET['edit'])) {
	 	
	 	$user_id = $_GET['edit'];

	 	$qry = 	"SELECT * FROM users where id='".$user_id."'";

	 	$result = mysqli_query($GLOBALS['conn'],$qry);

	 	if (mysqli_num_rows($result)>0) {
	 		
	 		while ($row= mysqli_fetch_array($result)){

             $_SESSION['investor_name'] = $row['name'];
              $_SESSION['investor_email'] = $row['email'];
           }

	 	} else{
	 	echo "error in user id".mysqli_error($GLOBALS['conn']);}
	 	}
 }

 // edit investment plans

        $plan_name ='';
        $min_deposit ='';
        $max_deposit = '';
        $return_freq = '';
        $return_percentage ='';
        $invest_duration ='';
    
 if (isset($_POST['submit-image'])) {
    

    // text field variables

    $plan_name = getInputData("plan_name");
    $min_deposit = getInputData("min_deposit");
    $max_deposit = getInputData("max_deposit");
    $return_freq = getInputData("return_freq");
    $return_percentage = getInputData("return_percentage");
    $invest_duration = getInputData("invest_duration");
    //
    if (empty($plan_name) || empty($min_deposit) || empty($max_deposit) 
        || empty($return_percentage)|| empty($return_freq) || empty($invest_duration)) {
       $upload_msg='One or all the fields are empty';
        $scss_class="alert-danger";
        return false;
    }

    // image variables
    $errors = array();
    $plan_image = time().'_'.$_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $temp = explode('.',$plan_image);
    $file_ext = strtolower(end($temp));



    $extension = array("jpeg","png","jpg","gif");

   
    if (in_array($file_ext, $extension)==false) {
       
         $upload_msg='file exension not allow. Please choose JPG,JPEG, PNG or GIF file';
        $scss_class="alert-danger";
        $errors[] = 'File extension error';
    }

     if ($file_size > 500000) {
        $upload_msg='File size  most be less than 500kb';
        $scss_class="alert-danger";
        $errors[] = 'bigger file error';
    }

    if (empty($errors)==true) {
       move_uploaded_file($file_tmp, 'plan_images/'.$plan_image);

        $qry = "INSERT INTO investment_plan VALUES('','$plan_name','$min_deposit','$max_deposit','$return_freq',
        '$return_percentage','$invest_duration','$plan_image')";

        $result = mysqli_query($GLOBALS['conn'],$qry);

        if ($result) {

         $upload_msg = 'Investment plan is added successfully';
        $scss_class = ' alert-success';

        }else{
             $upload_msg='Plan was not saved';
            $scss_class=' alert-danger';
        }

        $upload_msg = 'Investment plan is added successfully';
        $scss_class = ' alert-success';
 }
       
}


 if (isset($_POST['submit'])) {
    select_investor();
 }

 // selectall from investment plan

 function selectAllPlan(){

    $qry ="SELECT * FROM investment_plan ";

    $result = mysqli_query($GLOBALS['conn'],$qry);
    if ($result) {

      return $result;
    }else{
        echo "error". mysqli_error($GLOBALS['conn']);
    }
 }


 // update plans details

 // function update_plan(){

    // get the plan row id 

    if (isset($_GET['update'])) {
        
        $plan_id = $_GET['update'];
        $qry = "select * from investment_plan where id =".$plan_id;

        $result = mysqli_query($GLOBALS['conn'],$qry);

        if (mysqli_num_rows($result)>0) {

            while ($row = mysqli_fetch_array($result)){

             $_SESSION['plan_name'] = $row['plan_name'];
              $_SESSION['plan_id'] = $plan_id;
           }
        }
    }

            // update the given plan id

            if (isset($_POST['update-plan'])) {
                // code...
            $idNo = $_SESSION['plan_id'];

            $plan_name = getInputData("plan_name");
            $min_deposit = getInputData("min_deposit");
            $max_deposit = getInputData("max_deposit");
            $return_freq = getInputData("return_freq");
            $return_percentage = getInputData("return_percentage");
            $invest_duration = getInputData("invest_duration");

             if (empty($plan_name) || empty($min_deposit) || empty($max_deposit) 
             || empty($return_percentage)|| empty($return_freq) || empty($invest_duration)) {
            $upload_msg='One or all the fields are empty';
             $scss_class="alert-danger";
            return false;
        }

            //
            // image updating

            // image variables
            $errors = array();
            $plan_image = time().'_'.$_FILES['image']['name'];
            $file_size = $_FILES['image']['size'];
            $file_tmp = $_FILES['image']['tmp_name'];
            $file_type = $_FILES['image']['type'];
            $temp = explode('.',$plan_image);
            $file_ext = strtolower(end($temp));



            $extension = array("jpeg","png","jpg","gif");

   
    if (in_array($file_ext, $extension)==false) {
       
         $upload_msg='file exension not allow. Please choose JPG,JPEG, PNG or GIF file';
        $scss_class="alert-danger";
        $errors[] = 'File extension error';
    }

     if ($file_size > 500000) {
        $upload_msg='File size  most be less than 500kb';
        $scss_class="alert-danger";
        $errors[] = 'bigger file error';
    }

    if (empty($errors)==true) {
       move_uploaded_file($file_tmp, 'plan_images/'.$plan_image);

             $qry2 = "UPDATE investment_plan SET plan_name = '$plan_name', min_deposit= '$min_deposit', max_deposit = '$max_deposit', duration= '$invest_duration', return_fre= '$return_freq', return_percent= '$return_percentage', image= '$plan_image' where id = '$idNo';";


              $result2 = mysqli_query($GLOBALS['conn'],$qry2);

              if ($result2) {
                 $upload_msg = 'Investment plan updated successfully';
                 $scss_class = ' alert-success';
              }else{
                 $upload_msg = 'Investment plan not updated';
                $scss_class = ' alert-danger';
                echo "error".mysqli_error($GLOBALS['conn']);
              }
          }
      }

      // Delete plan from db

      if (isset($_POST['delete-plan'])) {
       
       $idNo = $_SESSION['plan_id'];

       $qry3 = "delete from investment_plan where id='$idNo'";
       if (mysqli_query($GLOBALS['conn'],$qry3)) {
         
          $upload_msg = 'Investment plan is removed successfully';
         $scss_class = ' alert-danger';

       }else{
         $upload_msg = 'Plan not removed...';
        $scss_class = ' alert-danger';

       }
      }

    
 // update admin info by including profile picture
      if (isset($_POST['update_profile'])) {
          
          // admin profie details


            $name = getInputData("name");
            $password = md5(getInputData("password"));
            $email_address = $_SESSION['admin_email'];

           // image variables
            $errors = array();
            $profile_image = time().'_'.$_FILES['profile_image']['name'];
            $file_size = $_FILES['profile_image']['size'];
            $file_tmp = $_FILES['profile_image']['tmp_name'];
            $file_type = $_FILES['profile_image']['type'];
            $temp = explode('.',$profile_image);
            $file_ext = strtolower(end($temp));



            $extension = array("jpeg","png","jpg","gif");

   
    if (in_array($file_ext, $extension)==false) {
       
         $upload_msg='file exension not allow. Please choose JPG,JPEG, PNG or GIF file';
        $scss_class="alert-danger";
        $errors[] = 'File extension error';
    }

     if ($file_size > 500000) {
        $upload_msg='File size  most be less than 500kb';
        $scss_class="alert-danger";
        $errors[] = 'bigger file error';
    }

    if (empty($errors)==true) {
       move_uploaded_file($file_tmp, 'plan_images/'.$profile_image);

       $qry5 = "UPDATE admin_info SET full_name = '$name', password ='$password', image= '$profile_image'
        where email = '$email_address'";

        $result5 = mysqli_query($GLOBALS['conn'],$qry5);

        if ($result5) {
          $upload_msg = 'Profile details changed successfully....';
         $scss_class = ' alert-success';

        }else{
             echo "error occured..".mysqli_error($GLOBALS['conn']);

        }

      }
      echo "error occured..".mysqli_error($GLOBALS['conn']);
  }

 // select all from admin
    // global variables for storing user info including profile picture
    $user_name='';
    $user_image='';
    $last_login = '';
  if (isset($_SESSION['admin_name'])) {
    $email_address = $_SESSION['admin_email'];

     $qry ="Select * from admin_info WHERE email='$email_address'";
     $result = mysqli_query($GLOBALS['conn'],$qry);

     if (mysqli_num_rows($result)>0) {
        
        while ($row = mysqli_fetch_array($result)) {

           $user_name =  $row['full_name'];
           $user_image = $row['image'];
           $last_login = $row['last_login'];
           
        }
     }
  }

  //***********************************************************************************************
    // php scrip for update bonus
  //************************************************************************************************
   $bonusVal ='';
  if (isset($_POST['update-bonus'])) {
     
      $bonusVal = getInputData('bonus');
      if ($bonusVal=='') {
        $upload_msg='Input field is empty...';
        $scss_class="alert-danger";
      }

     $bonusQry = "UPDATE users SET bonus= '$bonusVal'";
     if (mysqli_query($GLOBALS['conn'],$bonusQry)) {

        $upload_msg='Bonus value is updated successfully...';
        $scss_class="alert-success";
     }else{
        $upload_msg='Bonus value not inserted...';
        $scss_class="alert-danger";
        echo "error".mysqli_error($GLOBALS['conn']);
     }
  }

  // select from use table for update bonus

  if (isset($_GET['user_time_id'])){
  
      $sumAllInvestment=0;
      $principal =0;
      $interest =0; 
       $earning=0;
       $nowDate = date('y-m-d');  
       $earn_date ='';
       $startDate;
       $userId = $_GET['user_time_id'];
       $userName ='';
       $days ='';

  $qry =" select * from investments where id= ".$userId."";
  $results = mysqli_query($GLOBALS['conn'], $qry);
    
    if (mysqli_num_rows($results)>0) {
      
      while ($row = mysqli_fetch_array($results)){

              
              $sumAllInvestment+= $row['amount'];
               $earning = $row['earning'];
               $earn_date = $row['earn_date'];
              $startDate = $row['date'];
              $userName = $row['user'];
            }
            // echo  $userName;

            // Calculate the ROI of the invest daily
            // $now = date('y-m-d');
             // $startDate = $_SESSION['date'];
              $now = time();
             $from =  strtotime($startDate);
             $day_diff =  $now - $from;
              $days = floor($day_diff/(60*60*24));

              
      
    } else{
              $_SESSION['amount'] = 0.0;
              $_SESSION['plan'] = '';
              $_SESSION['status'] = '';
              $_SESSION['date'] = '';
  }
 
  }
 

    // this method update table each day daily return for the investers

  function updateEarning($principal,$earn_date,$userId){
   
   
    

    $qry  ="UPDATE investments SET earning='$principal', earn_date='$earn_date' WHERE id='$userId'";
    $result = mysqli_query($GLOBALS['conn'],$qry);

    if ($result) {
                    
                    return $result;
   
    
                }else{
                    $upload_msg='No earning updated...';
                     $scss_class="alert-danger";
             }
            }


//update time for the investment for particular user

if (isset($_POST['update_amount'])) {
        
   
                 // day 1

               if ($days == 1) {
              
                $interest = $sumAllInvestment*1*0.1; 
                $principal = $sumAllInvestment+$interest;
                 updateEarning($principal,$nowDate,$userId);
                 $upload_msg='New earning updated successfully...';
                    $scss_class="alert-success";
                 
              }

              // day 2

             elseif ($days==2) {
               $interest = $sumAllInvestment*2*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate,$userId);
                  $upload_msg='New earning updated successfully...';
                    $scss_class="alert-success";
              }
              // day three

                elseif ($days==3 ) {
               $interest = $sumAllInvestment*3*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate,$userId);
                  $upload_msg='New earning updated successfully...';
                    $scss_class="alert-success";

              }
              // day four

                elseif ($days==4) {
               $interest = $sumAllInvestment*4*0.1; 
                $principal = $sumAllInvestment+$interest;
                updateEarning($principal,$nowDate,$userId);
                $upload_msg='New earning updated successfully...';
                    $scss_class="alert-success";
              }

                // day five

                elseif ($days==5) {
               $interest = $sumAllInvestment*5*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate,$userId);
                  $upload_msg='New earning updated successfully...';
                    $scss_class="alert-success";
              }
              // day 6

                elseif ($days==6) {
               $interest = $sumAllInvestment*6*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate,$userId);
                  $upload_msg='New earning updated successfully...';
                    $scss_class="alert-success";
              }
              // day 7

                elseif ($days==7) {
               $interest = $sumAllInvestment*7*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate,$userId);
                  $upload_msg='New earning updated successfully...';
                    $scss_class="alert-success";
              }else{

                $interest = $sumAllInvestment*7*0.1; 
                $principal = $sumAllInvestment+$interest;
                updateEarning($principal,$nowDate,$userId);
                $upload_msg='New earning updated successfully...';
                    $scss_class="alert-success";
              }
}

// Calculate total user 
if (isset($_SESSION['admin_name'])) {
  $count =0;
  $sumAllInvestment=0;

  $qry = "select count(*) as count from users";
  $result = mysqli_query($GLOBALS['conn'],$qry);
  
  if (mysqli_num_rows($result)>0) {
      
   while($row = mysqli_fetch_array($result)){

    $count = $row['count'];
  } 
  }

  // all investment 


  $qry =" select amount from investments";
  $results = mysqli_query($GLOBALS['conn'], $qry);
    
    if (mysqli_num_rows($results)>0) {
      
      while ($row = mysqli_fetch_array($results)){

              
              $sumAllInvestment+= $row['amount'];
              
            }
  
}
}

//request a particular users messages and display it to the user

function userMessage(){
if (isset($_SESSION['admin_email'])) {
 $subject='';
 $message= '';

 $qry  = "SELECT * from support ORDER BY id DESC";

 $result  = mysqli_query($GLOBALS['conn'],$qry);
 if (mysqli_num_rows($result)>0) {
   
  return $result;
 }else{
    echo "No message yet";
 }
}
}