

	<?php
	/**
	 * db connection class for btc website
	 */

	
			define("DB_HOST", "127.0.0.1:3305");
			define("DB_USER", "root");
			define("DB_PASS", "");
			define("DB_NAME", "crypto");
	?>

	<?php
	class DbConnection
	{
		public $HOSTNAME = DB_HOST;
		public $USERNAME = DB_USER;
		public $PASSWORD = DB_PASS;
		public $DBNAME = DB_NAME;

		public $link;
		public $error;

		public function  __construct(){

		 $this->connect();
		}

		public function connect(){
		$this->link = new mysqli($this->HOSTNAME,$this->USERNAME,$this->PASSWORD,$this->DBNAME);

		if (!$this->link) {

			$this->error ="Connection fail".$this->link->connect_error;
			return false;
		}
		return $this->link;
	}
		
	}

	