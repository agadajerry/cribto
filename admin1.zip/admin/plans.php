<?php include ('config/users_data.php');
 
if(!isset($_SESSION["admin_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body>
    
    <!-- vertical menu -->

     <?php include 'header.php'?>

        <!-- Page Content  -->
     <div id="content" class="p-4 p-md-5 pt-5 page-content">
       <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
        <h2 class="mb-4">Plans</h2>

        <div class="d-flex justify-content-between">
            <h4 class="">Investment plans</h4>
            <a href="add_plans.php" class="btn btn-primary btn-sm mt-1">Add Plan</a>
        </div>
        
        <!-- table of widthrawals -->
  <table class="table mt-4 table-striped" id="investment_table">
        
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Max deposit</th>
          <th>Min deposit</th>
          <th>Frequency</th>
          <th>Return %</th>
          <th>Duration</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
    
            <?php

            if (isset($_SESSION['admin_name'])):?>
            <?php $id =0; ?> 

           <?php   $result = selectAllPlan();?>

             <?php if (mysqli_num_rows($result)>0):?>
    
           <?php while ($row= mysqli_fetch_array($result)):?>
               <tr>
              <?php $id++; ?> 
             <td><?php echo $id; ?></td>
             <td hidden="true"><?php echo $row['id']; ?></td>
             <td><?php echo $row['plan_name']; ?></td>
             <td><?php echo $row['min_deposit']; ?></td>
             <td><?php echo $row['max_deposit']; ?></td>
             <td><?php echo $row['return_fre']; ?></td>
             <td><?php echo $row['return_percent']; ?></td>
             <td><?php echo $row['duration']; ?></td>
             <td><img src="plan_images/<?php echo $row['image'];?> "style="width: 50px; height: 50px; margin-right: 5px;" class="mr-1 rounded-circle img-thumbnail shadow-sm"></td>
             <td><a href="Edit_plans.php?update=<?php echo $row['id']; ?>" class="btn btn-primary">Edit</a></td>
    </tr>
        <?php endwhile; ?>
         <?php endif; ?>
          <?php endif; ?>
          
    
         
      </tbody>
</table>
       
 </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>
    
  </body>
</html>