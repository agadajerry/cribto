<?php  include ('config/registers_data.php');

if(!isset($_SESSION["my_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
  </head>
  <body>
    
    <!-- vertical menu -->

    <?php include 'header.php'?>


        <!-- Page Content  -->
     <div id="content" class="p-4 p-md-5 pt-5 page-content">
       <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
        <h2 class="mb-4"> Invest</h2>
         <!-- Make payment -->

            <!-- cards hold btc address inform information -->

        <div class="row">
          <div class="col-md-9">
            <div class="bg-success mb-3">
              
              <p class=" py-4 px-3" style="color:white;">
                <?php echo 'Payment Initiated for your ' .$planName.' investment. Send an amount between $'.$mini_deposit.' and  $'.$maxi_deposit.' to the Bitcoin address below';?></p>
            </div>
            <div class="card">
        <ul class="list-group list-group-flush">
          <li class="list-group-item bg-white">
            <p>Bitcoin address</p>
          </li>
          <li class="list-group-item"><h3>1FJwBHQaZn95rLfSJfzgzFdEUsmuXUKjDQ</h3></li>
          <li style="margin: 0 auto;"><img src="images/btc_qrc_test.png" class="m-5" style="width:200px; height: 200px;"></li> 
        </ul>
      </div>
        </div>
        
 
       
 </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
  </body>
</html>