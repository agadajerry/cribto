<?php include 'config/crypto_price.php'?>
<?php include( 'config/plans.php')?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Bullish assets - Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="script2/index.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    
  </head>

  <body>
  <div id="google_translate_element"></div>
  <header class="header">
    <!-- nav bar -->
  <nav class="navbar navbar-expand-sm navbar-light bg-white">
    <div class="mx-auto d-sm-flex d-block flex-sm-nowrap">
        <a class="navbar-brand" href="index.php"><img src="images/logo.png" id="logo"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample11" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse text-center" id="navbarsExample11">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#price">Prices</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#contact">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#about">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn-info" href="registration.php" style="color:#fff;">Register</a>
                </li>
            </ul>
        </div>
    </div>
</nav>


    <!-- end of navbar -->
</header>
      <div class="container-fluid" style="background:#fff; padding:0 40px;">
        <div class="row">
          <div class="col-sm-6 mb-3 col-info">
            <h3>
              Successful Crypto <br>Trading Investment.
            </h3>
            <span class="subhead mb-5 mt-3">
                Start earning smooth as 1-2-3!
              </span>
            <a href="#moreaboutus" class="btn btn-primary btn-lg mt-5">Learn More</a>
            <a href="registration.php" class="btn btn-success btn-lg mt-5" >Sign Up</a>
          </div>
          <div class="col-sm-6 col-img mb-3 mt-5">
            <img src="images/crypto.png" class="img-responsive showcase-img" id="slider">
          </div>
        </div>
      </div>

        <!-- end of header section -->

        <!-- content container -->

         <div class="container-fluid" style="padding: 0 40px;margin-left: 6px;background:#354d73">
        <div class="row">
          <div class="col-md-6 mb-4 about-us">
             <h3>live Update</h3>
          <p style="color:#fff;">Live update of some cryptocurrenecies</p>
  <table class="table table-dark table-striped">
  <thead>
    <tr>
     
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>BTC</td>
      <td id="btcP">$<?php echo number_format($btc,2) ;?></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>ETH</td>
      <td>$<?php echo number_format($eth,2);?></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>BNB</td>
      <td>$<?php echo number_format($bnb,2) ;?></td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>LTC</td>
      <td>$<?php echo number_format($ltc,2);?></td>
    </tr>
  </tbody>
</table>
          </div>
   
        <div class="col-md-6 about-us">
            <h3>Why Should You Choose Us?</h3>
            <p style="color:#fff;">Our company provides access to professional cryptocurrency trading for each of you, regardless of experience in this field and regardless of how much money is in your possession. The combination of unique strategies with the use of trading robots allows us to get a stable result and pay high dividends to our customers. Choosing the trending Quantum AI trading platform will give you a new trading experience. This trading app uses quantum computing to execute the trade autonomously. The app has potential to analyze various trading processes due to its remarkable computing tendency. Right now, the app is in use in Asia, North America and Europe. Have a look at the quantum ai trading app review to learn more about the app and also open an account now. You can start earning with BULLISH ASSETS right now - just register on our website, choose the best investment solution and invest the amount available to you. After that, your funds will begin to work on cryptocurrency exchanges, and you will start getting profit that is completely passive!. </p>
          </div>
      </div>
    </div>

<!-- our investment -->

<div class="container-fluid mt-4" style="background:#fff; margin-bottom: 30px;" id="price">
  <div class="container">
            <!-- plan table -->
            <div class="row">
              <!-- investment plan inffo -->
              <h3 class="text-center">investment plans</h3>
            <p class="text-center">Our investment plans is available to all categories of investors. </p>

          <?php  $result = selectAllPlan();?>

          <?php  if (mysqli_num_rows($result)>0):?>

           <?php while ($row = mysqli_fetch_array($result)):?>

            <div class="col-md-4 shadow p-3 mb-5 bg-white rounded">
            <div class="card ">
              <div class="card-header" style="background:#ad08f8; color:#fff;">
                <h3 class="text-center"><?php echo $row['plan_name'];?></h3>
                <h1 class="text-center"><?php echo $row['return_percent']; ?>%</h1>
              </div>
              <ul class="list-group list-group-flush">
                <li class="list-group-item"><?php echo 'Daily for ' .$row['duration'].' Days'; ?></li>
                <li class="list-group-item"><?php echo 'Total Profit '.$row['return_percent']*$row['duration'].'%'; ?></li>
                <li class="list-group-item"><?php echo 'Minimum Deposit ' .$row['min_deposit'].'$'; ?></li>
                <li class="list-group-item"><?php echo 'Maximum Deposit ' .$row['max_deposit'].'$'; ?></li>
              </ul>
                </div>
              </div>
              <?php endwhile;?>
              <?php endif;?>
            </div>
          </div>
          <div class="container signbtn bg-dark">
      <a href ="registration.php" class="btn btn-primary btn-lg">Sign Up Now</a>
    </div>
        </div>
          <!-- end of investment plan -->

    
   
<!-- core product -->
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <h3 class="text-center mb-4">How does it work?</h3>
            
          </div>
        </div>
        <div class="col-md-3"></div>
      </div>

      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="card shadow p-3 mb-5 bg-white rounded">
              <div class="card-body">
                <h5 class="card-title">OPEN AN ACCOUNT</h5>
                <p class="card-text">To sign up for an account, simply click the registration button and fill out the analogous form.</p>
            </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card shadow p-3 mb-5 bg-white rounded">
              <div class="card-body">
                <h5 class="card-title">MAKE A DEPOSIT</h5>
                <p class="card-text">Analysis of our investment plans and judge the one which fits your allocation and the profit which you want to have. </p>
            </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card shadow p-3 mb-5 bg-white rounded">
              <div class="card-body ">
                <h5 class="card-title">WATCH YOUR PROFIT GROW</h5>
                <p class="card-text">Watch your earnings amass according to the earning slate of the plan that you have made deposit into.</p>
            </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card shadow p-3 mb-5 bg-white rounded">
              <div class="card-body">
                <h5 class="card-title">Instant Payout </h5>
                <p class="card-text">The payout utility is available to all purchaser, once payment request is proposed; withdrawal will pay instantaneously.</p>
            </div>
            </div>
          </div>
        </div>
      </div>
  
    
    <!-- Range of profitable strategy -->
    <div class="container-fluid" style="background: #002; padding: 50px;">
      <h3 class="text-center mb-5">Project statistics</h3>
        <div class="row mb-3 biz-profit">

          <div class="col-md-3">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title text-center">Binance Signals</h5>
                <p class="card-text text-center">Total profit: +300.54%</p>
            </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title text-center">MoonBot</h5>
                <p class="card-text text-center">Total profit: +410.12%</p>
            </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title text-center">Crypto Rocket Lite</h5>
                <p class="card-text text-center">Total profit: +145%</p>
            </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title text-center">MTC Omega</h5>
                <p class="card-text text-center">Total profit: +300.54%</p>
            </div>
            </div>
          </div>
        </div>

        <!-- Site total earning and vist -->

         <div class="row mb-3 biz-profit mt-5">
          <div class="col-md-3">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title text-center">Works days</h5>
                <p class="card-text text-center">7</p>
            </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title text-center">Total users</h5>
                <p class="card-text text-center">463</p>
            </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title text-center">Total accepted</h5>
                <p class="card-text text-center">$ 7,449.93</p>
            </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title text-center">Total withdrawals</h5>
                <p class="card-text text-center">$ 3,179.92</p>
            </div>
            </div>
          </div>
        </div>
    </div>

    

<!-- get a qoute today -->
<div class="container mb-5 p-3">
  <div class="row">
    <div class="col-md-6 mb-4">
      <h3>Get A Quote</h3>
      <p>We’re available 24hours a day! Contact to require a detailed analysis and assessment of your plan.</p>
      <a href="#contact" class="btn btn-primary btn-lg">Get A Quote</a>
    </div>
    <div class="col-md-6">
      <img src="images/exchange.jpg" class="img-responsive showcase-img">
    </div>
  </div>
</div>
<!-- FAQ -->
<div class="container mb-5">
  <h3 class="mb-5 text-center"> Frequently asked Questions</h3>

  <div class="row">
    <div class="col-md-6">
      
  <div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
      <button class="accordion-button" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        How do I get started?
      </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="accordion-body">
        First of all, Click on 'SignUp' menu and provide your correct details. You'll receive a registration bonus upon login to your dashboard.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
      <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
       How do I make an Investment
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="accordion-body">
        Login to your account, click on the top-left menu button, then click on "invest" button and select the most suitable plan for you. After creating the investment, you will be required to make a transfer of exact investment amount to a bitcoin address. After payment, your account gets updated automatically and your earnings start counting.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        How do I make a Withdrawal
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="accordion-body">
        You can withdraw immediately after your investment cycle ends
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingFour">
      <button class="accordion-button collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
       Can I terminate/end my investments anytime?
      </button>
    </h2>
    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
      <div class="accordion-body">
        Yes you can terminate/end your investment at anytime by sending us a message from your dashboard, requesting for termination of investment and withdrawal of capital , this will take 2 working days to process and after that the investors automatically receives the total capital invested.
      </div>
    </div>
  </div>
</div>
<a href="#" class="btn btn-primary btn-lg mt-5 mb-3">Get A Quote</a>
    </div>
    <div class="col-md-6">
      <img src="images/FAQ.png" class="showcase-img">

    </div>
  </div>
</div>

  <!-- testmonial section -->

  <div class="container-fluid mb-5" style="background:#354d73">
    <div class="container" style="background:#354d73">
    <h3 class="mb-5 text-center"> What People Are Saying</h3>
    <div class="row testmonial">

       <div class="col-md-4">
        <div class="card text-center">
        <div class="text-center">
          <img src="images/testm1.jpg" class="card-img-top mt-2" style="width:90px; height:90px; border-radius: 50%;">
        </div>
        <div class="card-body">
        
        <h4 class="card-title">Gaire Surya</h4>
        <h5>Most suitable digital investment partner.</h5>
         <p class="card-text leading">There are thousands of digital investment service companies in the world. Their popularity and reputation are just evident.</p>
  </div>
</div>
</div>
     <div class="col-md-4">
        <div class="card text-center">
        <div class="text-center">
          <img src="images/test2.jpg" class="card-img-top mt-2" style="width:90px; height:90px; border-radius: 50%;">
        </div>
        <div class="card-body">
        
        <h4 class="card-title">William Bright</h4>
        <h5>Friend For Life!.</h5>
         <p class="card-text leading">Digital Currency investment service is not an easy path to follow. But these guys can make it to the top with premium services and dedicated customer support.</p>
  </div>
</div>
</div>
     <div class="col-md-4">
        <div class="card text-center">
        <div class="text-center">
          <img src="images/test3.jpg" class="card-img-top mt-2" style="width:90px; height:90px; border-radius: 50%;">
        </div>
        <div class="card-body">
        
        <h4 class="card-title">Ethan Eric</h4>
        <h5>Digital investment service made easy.</h5>
         <p class="card-text leading">I discovered @BullishAssets by chance on the Internet to find a suitable digital investment services . This must be fate, not an accident at all.</p>
  </div>
</div>
</div>
  </div>
  </div>
</div>

 


<!-- Footer -->
<footer class="text-center text-lg-start bg-light text-muted">
  <!-- Section: Social media -->
  <section
    class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
    <!-- Left -->
    <div class="me-5 d-none d-lg-block">
      <span>Get connected with us on social networks:</span>
    </div>
    <!-- Left -->

    <!-- Right -->
    <div>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-google"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-instagram"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-linkedin"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-github"></i>
      </a>
    </div>
    <!-- Right -->
  </section>
  <!-- Section: Social media -->

  <!-- Section: Links  -->
  <section class="">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <h6 class="text-uppercase fw-bold mb-4" id="about">
            <i class="fas fa-gem me-3"></i>Bullish AssetsFx
          </h6>
          <p class="leading">
            We are a dynamic group whose main focus is to provide our clients with the best possible service, We apply a systematic and quantitative approach to investment management, with the aim of generating high-quality and diversifying alpha for its clients portfolios with focus on trading and mining cryptocurrencies on contract for investors, and ensuring the highest possible return on investment within manageable risk. We are here to ensure your investment continue to generate yields without you having to get involved yourself.
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            EXCHANGES
          </h6>
          <p>
            <a href="https://www.binance.com" class="text-reset">Binance</a>
          </p>
          <p>
            <a href="https://www.coinbase.com" class="text-reset">Coinbase</a>
          </p>
          <p>
            <a href="https://www.bitrue.com" class="text-reset">Bitrue</a>
          </p>
          <p>
            <a href="https://www.crypto.com" class="text-reset">Crypto.com</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Useful links
          </h6>
          <p>
            <a href="index.php" class="text-reset">Home</a>
          </p>
          <p>
            <a href="#price" class="text-reset">Pricing</a>
          </p>
          <p>
            <a href="login.php" class="text-reset">Login</a>
          </p>
          <p>
            <a href="registration.php" class="text-reset">Register</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4" id ="contact">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Contact
          </h6>
          <p><i class="fas fa-home me-3"></i> New York, NY 10012, US</p>
          <p>
            <i class="fas fa-envelope me-3"></i>
            admin@bullishassetfx.co.uk
          </p>
          <p><i class="fas fa-phone me-3"></i> + 01 234 567 88</p>
          <p><i class="fas fa-print me-3"></i> + 01 234 567 89</p>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->

  <!-- Copyright -->
  <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2021 Copyright:
    <a class="text-reset fw-bold" href="https://bullishassetfx.co.uk/">BullishAssetFx</a>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->
<!-- Footer -->

      <!-- end of content container-->
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script>
  let email = document.getElementById('email');
  let subject = document.getElementById('subject');
  let message = document.getElementById('message');
  let submit = document.getElementById('submit');

  submit.onclick = function(){

    if (subject.value===''|| message.value===''|| email.value==='' || email.value.length<=3) {
    return false;

  }

  }

</script>

<!-- This is for picture animation -->

<script>
  
 
  let num =0;
  let picArr = ['images/crypto.png','images/cryptoC1.jpg','images/exchange.jpg'];

  setInterval(function(){
    if(num === picArr.length){
      num =0;
    }
     let slider = document.getElementById('slider').src = picArr[num];
     num++;
  },5000);


</script>
  </body>

  </html>

