<?php  include ('config/registers_data.php');

if(!isset($_SESSION["my_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body>
    
    <!-- vertical menu -->

    <?php include 'header.php'?>


        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5 page-content">
        <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
        <h2 class="mb-4">Affiliates</h2>
        
          <div class="row mb-4">
          
          <div class="col-md-3">
            <div class="card first-card-bg">
              <div class="card-body">
                <?php if (isset($_SESSION['my_name'])):?>
                  <h5 class='card-title'> <?php echo $referral_code; ?></h5>
                <?php endif;?>
                
                <p class="card-text">Referral Code</p>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
              <div class="card-body second-card-bg">
                <h5 class="card-title">Affiliate Earning</h5>
                <p class="card-text">$0.00</p>
              </div>
            </div>
          </div>
        </div>
          <!-- end of cards -->

          <!-- table of referrals -->
          <table class="table mt-4 table-striped" id="affiliate_table">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Date</th>
            </tr>
          </thead>
          <tbody>
            
            <tr>
              
              <td>No record yet</td>
            </tr>
          </tbody>
        </table>
 </div>
  <!-- end of content container-->
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>
    <script>
      $(document).ready(function() {
    $('#affiliate_table').DataTable();
} );
    </script>
  </body>
</html>