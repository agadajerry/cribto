<?php

$url = "https://api.binance.com/api/v3/ticker/price";

$data = file_get_contents($url);
$json = json_decode($data,true);
$btc= 0;
$eth =0;
$bnb =0;
$ltc = 0;

if ($data!=FALSE) {
	foreach ($json as $key => $value) {
	
	if ($value['symbol']!='') {
		// code...
	
	if ($value['symbol']== "BTCUSDT") {
		
		$btc = $value['price'];
	}elseif ($value['symbol']== "ETHUSDT") {
		
		$eth =  $value['price'];
	}
	elseif ($value['symbol']== "LTCUSDT") {
		
		$ltc =  $value['price'];
	}
	elseif ($value['symbol']== "BNBUSDT") {
		
		$bnb =  $value['price'];
	}
}else{
	echo "error";
}
}
}else{
	echo "error occured";
}




