<?php session_start(); 
include 'config/dbConnect.php';
  
  // Global variables
    $alert_msg ='';
    $alert_class ="";
   
      
	$my_con =  new DbConnection();
 	$conn = $my_con->connect();

 if (isset($_POST['submit'])) {
 	
 	addData();
 }

 if (isset($_POST['login'])) {
 	
 	login();
 }
 if (isset($_POST['logout'])) {
 	 		header("location: login.php");
			// session_destroy();
 }

//get data from field
  function addData()
 {
   	$fullname = getInputData("fullname");
   	$email = getInputData("email");
   	$password = md5(getInputData("password"));
   	$referral = getInputData("referral_code");
    $referral_code  = substr(str_shuffle(str_repeat("0123456789abcdefghijklonopqrstuvwxyz", 5)), 0, 5);//referral code gen
    $dates =  date('y-m-d H:i:s');

 		$select_user = "SELECT * FROM users where email = '".$email."'";

 		$result = mysqli_query($GLOBALS['conn'], $select_user);

 		if (mysqli_num_rows($result)>0){

 			$_SESSION['email_exist']= "The email you are trying to used already exist"; 			
 			
 		}else{
 	if ($fullname && $email && $password) {

	$qry  ="INSERT INTO users (id, name, email, password, image, referrals, referral_code, last_login, bonus) VALUES(
 	'','$fullname','$email','$password','admin.png','$referral','$referral_code','$dates','53.45')";

 	if (mysqli_query($GLOBALS['conn'],$qry)) {

 		   // $_SESSION['my_reg_email']= $email;
      //   $_SESSION['my_reg_name']= $fullname;

        // login();

 		header("location: login.php");
   
 	}
 }else{
 	echo "".mysqli_error($GLOBALS['conn']);
 }
}
}

// login section 
  $email='';
 
function login()
 {
   
 	$email = getInputData("email");
 	$password = md5(getInputData("password"));


 		$select_user = "SELECT * FROM users where email = '".$email."' AND password = '".$password."'";

 		$result = mysqli_query($GLOBALS['conn'], $select_user);

 		if (mysqli_num_rows($result)==0){

 			$_SESSION['email_exist']= "The login information is incorrect"; 			
 			
 		}else{

      if (mysqli_num_rows($result)>0) {
    
           while ($row= mysqli_fetch_array($result)){

             $my_name = $row['name'];
           }


         // update last login details
          $date =  date('y-m-d H:i:s');
        $lastLoginQry = "UPDATE users SET last_login= '$date' WHERE email='$email'";
        if (mysqli_query($GLOBALS['conn'],$lastLoginQry)) {
        }else{
            echo "error".mysqli_error($$GLOBALS['conn']);
        }

        // session user info 
       $_SESSION['my_email']= $email;
        $_SESSION['my_name']= $my_name;
         header("location:user_index.php");  
}
}
}


 function getInputData($textvalue)
 {
 	$inputText  = mysqli_real_escape_string($GLOBALS['conn'],trim($_POST[$textvalue]));

 	if(empty($inputText)){
 		return false;
 	}else{
 		return $inputText;
 	}
 }


 function actionMsg($class,$msg)
 {
 	$msg = "<h6 class ='$class'>$msg</h6>";

 	echo $msg;
 }


 // seect from investment table fro paticular investor

     if (isset($_SESSION['my_email'])){
  
      $sumAllInvestment=0;
      $principal =0;
      $interest =0; 
       $earning=0;
       $nowDate = date('y-m-d');  
       $earn_date ='';
       $days;

  $qry =" select * from investments where email='".$_SESSION['my_email']."'";
  $results = mysqli_query($GLOBALS['conn'], $qry);
    
    if (mysqli_num_rows($results)>0) {
      
      while ($row = mysqli_fetch_array($results)){

              
              $sumAllInvestment+= $row['amount'];

               $earning = $row['earning'];
               $earn_date = $row['earn_date'];
              $_SESSION['amount'] = number_format($sumAllInvestment,2);
              $_SESSION['plan'] = $row['plan'];
              $_SESSION['status'] = $row['status'];
              $_SESSION['date'] = $row['date'];
            }

           
            /*
            *
            * Earning date comparing to date now
            *
             */

              
            // Calculate the ROI of the invest daily
            // $now = date('y-m-d');
             $startDate = $_SESSION['date'];
              $now = time();
             $from =  strtotime($startDate);
             $day_diff =  $now - $from;
              $days = floor($day_diff/(60*60*24));


              // day 0

             if ($days == 0) {
              
                $interest = $sumAllInvestment*0*0.1; 
                $principal = ($sumAllInvestment+$interest);
                 updateEarning($principal,$nowDate);
              }

              // day 1
               if ($days == 1) {
              
                $interest = $sumAllInvestment*1*0.1; 
                $principal = ($sumAllInvestment+$interest);
                 updateEarning($principal,$nowDate);
              }

              // day 2

             elseif ($days==2) {
               $interest = $sumAllInvestment*2*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate);
              }
              // day three

                elseif ($days==3 ) {
               $interest = $sumAllInvestment*3*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate);
              }
              // day four

                elseif ($days==4) {
               $interest = $sumAllInvestment*4*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate);
              }

                // day five

                elseif ($days==5) {
               $interest = $sumAllInvestment*5*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate);
              }
              // day 6

                elseif ($days==6) {
               $interest = $sumAllInvestment*6*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate);
              }
              // day 7

                elseif ($days ==7) {
               $interest = $sumAllInvestment*7*0.1; 
                $principal = $sumAllInvestment+$interest;
                  updateEarning($principal,$nowDate);
              }
      
    } else{
              $_SESSION['amount'] = 0.0;
              $_SESSION['plan'] = '';
              $_SESSION['status'] = '';
              $_SESSION['date'] = '';
  }
 
  }


  // Select entry for a particular investor and display on table

  function select_investor(){


  $qry =" select * from investments where email='".$_SESSION['my_email']."'";
  $results = mysqli_query($GLOBALS['conn'], $qry);
    
    if (mysqli_num_rows($results)>0) {
      
      return $results;
      
    } else{

       return $results;
    }
  }
  

 // seect from investment table

 function select_payment(){

  $qry =" select * from payment where email= '".$_SESSION['my_email']."'";
  $result = mysqli_query($GLOBALS['conn'], $qry);

  
  return $result;
 }

 // if (isset($_SESSION['my_email'])) {
 //  select_investors();
 // }

if (isset($_SESSION['my_email'])) {
  echo '';
 }else{
  // header("Location:registration.php");// redirect to reg page if user is not find

 }
 
 // selectall from investment plan

 function selectAllPlan(){

    $qry ="SELECT * FROM investment_plan ";

    $result = mysqli_query($GLOBALS['conn'],$qry);
    if ($result) {

      return $result;
    }else{
        echo "erroor". mysqli_error($GLOBALS['conn']);
    }
 }

    $planName='';
    $maxi_deposit =0;
    $mini_deposit =0;
 if (isset($_GET['get_invest_info'])) {
   
   $rId = $_GET['get_invest_info'];

   $qry = "select * from investment_plan where id='$rId'";

    $result = mysqli_query($GLOBALS['conn'],$qry);

    if (mysqli_num_rows($result)>0) {
      
      while ($row= mysqli_fetch_array($result)){

              $planName = $row['plan_name'];
              $maxi_deposit = $row['max_deposit'];
              $mini_deposit = $row['min_deposit'];

           }

    } else{
    echo "error in user id".mysqli_error($GLOBALS['conn']);}
 }


 // update admin info by including profile picture

      if (isset($_POST['update_profile'])) {
          
          // admin profie details


            $name = getInputData("name");
            $password = md5(getInputData("password"));
            $email_address = $_SESSION['my_email'];

           // image variables
            $errors = array();
            $profile_image = time().'_'.$_FILES['profile_image']['name'];
            $file_size = $_FILES['profile_image']['size'];
            $file_tmp = $_FILES['profile_image']['tmp_name'];
            $file_type = $_FILES['profile_image']['type'];
            $temp = explode('.',$profile_image);
            $file_ext = strtolower(end($temp));

            $extension = array("jpeg","png","jpg","gif");

   
    if (in_array($file_ext, $extension)==false) {
       
         $upload_msg='file exension not allow. Please choose JPG,JPEG, PNG or GIF file';
        $scss_class="alert-danger";
        $errors[] = 'File extension error';
    }

     if ($file_size > 500000) {
        $upload_msg='File size  most be less than 500kb';
        $scss_class="alert-danger";
        $errors[] = 'bigger file error';
    }

    if (empty($errors)==true) {
       move_uploaded_file($file_tmp, '../admin/plan_images/'.$profile_image);

       $qry5 = "UPDATE users SET name = '$name', password ='$password', image= '$profile_image'
        where email = '$email_address'";

        $result5 = mysqli_query($GLOBALS['conn'],$qry5);

        if ($result5) {
          $upload_msg = 'Profile details changed successfully....';
         $scss_class = ' alert-success';

        }else{
             echo $upload_msg .mysqli_error($GLOBALS['conn']);

        }

      }else{
      return false;
    }
  }

 // select all from admin
    // global variables for storing user info including profile picture
    
    // global variables
  $last_login = '';
  
  if (isset($_SESSION['my_name'])) {
    $user_name='';
    $user_image='';
     $bonusAmount =0;
    $email_address = $_SESSION['my_email'];
    $referral_code ='';

     $qry ="SELECT * from users WHERE email = '$email_address'";
     $result = mysqli_query($GLOBALS['conn'],$qry);

     if (mysqli_num_rows($result)>0) {
        
        while ($row = mysqli_fetch_array($result)) {

           $user_name =  $row['name'];
           $user_image = $row['image'];
           $last_login = $row['last_login'];
           $bonusAmount = $row['bonus'];
           $referral_code = $row['referral_code'];
 
        }
     }
  }

  // this method update table each day daily return for the investers

  function updateEarning($principal,$earn_date){
   
   
    $email_address = $_SESSION['my_email'];

    $qry  ="UPDATE investments SET earning='$principal', earn_date='$earn_date' WHERE email='$email_address'";
    $result = mysqli_query($GLOBALS['conn'],$qry);

    if ($result) {
    return $result;
   
    
  }
}

// send support to the database

if(isset($_POST['report'])){
 
  $email =  $_SESSION['my_email'];
  $subject = getInputData("subject");
  $message = getInputData("message");

  $qry  = "INSERT INTO support (id, email, subject, message) VALUES('','$email', '$subject', '$message')";

  if (mysqli_query($GLOBALS['conn'],$qry)) {
    
          $alert_msg='Your request is sent successfully...';
          $alert_class="alert-success";
  }else{
    echo "support or request not uploaded".mysqli_error($GLOBALS['conn']);
}  }

//request a particular users messages and display it to the user

function userMessage(){
if (isset($_SESSION['my_email'])) {
 
$email =  $_SESSION['my_email'];


 $qry  = "SELECT * from support WHERE email ='$email' ORDER BY id DESC";

 $result  = mysqli_query($GLOBALS['conn'],$qry);
 if (mysqli_num_rows($result)==0) {
   echo "no data found";
 
 }else{
   return $result;
 }

}
}

// Withdrawal section

if (isset($_POST['withdraw'])) {
 
 // temporary message when user want make withdraw

  $alert_class ='alert alert-success';
  $alert_msg = 'your request is submitted successfully.<br> you will get your money if you have money in your balance to withdraw...';

}


// Sendig an email

