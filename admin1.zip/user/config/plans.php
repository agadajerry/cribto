<?php
include 'config/dbConnect.php';
  
  // Global variables
    $alert_msg ='';
    $alert_class ="";
   
      
	            $my_con =  new DbConnection();
 	           $conn = $my_con->connect();

 

               function selectAllPlan(){

            $qry ="SELECT * FROM investment_plan ";

            $result = mysqli_query($GLOBALS['conn'],$qry);
            if ($result) {

              return $result;
             
            }else{
                echo "erroor". mysqli_error($GLOBALS['conn']);
            }
          }
 