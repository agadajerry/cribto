<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body style="background:gray;">
    
       <!-- registration form start from here -->
       <div class="container mt-5">
         <div class="row">
           <div  class="col-md-4"></div>

            <div  class="col-md-4 mt-3">
              <div class="card shadow-sm p-3 mb-5 bg-white rounded mt-3">
                <div class="card-body">
                  <div style="text-align:center;">
                 <h5 style="margin-top: 10px;">CRYPTO INVESTORS</h5>
                 </div>
                  <div class="card-title text-center py-3"><h5>Enter your email address</h5></div>
              <form>
                <div class="input-group has-validation mb-3">
                  <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-envelope"></i></span>
                  <input type="email" class="form-control" id="email" aria-describedby="email" placeholder="Email address">
                </div>
                  <div class="mb-3 regbtn">
                <button type="submit" class="btn btn-primary mb-2">Send</button>
                  <a href="registration.php" class="account_already"> Have no account?</a>
                </div>
              </form>
            </div>
             <div  class="col-md-4"></div>
         </div>
       </div>
     </div>
   </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>
    <script >
       $(document).ready(function() {
    $('#investment_table').DataTable();
} );
    </script>
  </body>
</html>