 <div class="vertical-nav overflow-auto" id="sidebar">
      <div class="py-4 px-3 mb-2">
        <div class="text-center">
          <?php if(!empty($user_name)):?>
         <img src="../admin/plan_images/<?php echo $user_image;?>" style="width: 80px; height: 80px; margin-right: 5px;" class="mr-1 rounded-circle img-thumbnail shadow-sm">
       <?php endif; ?>
        </div>
        <div class="text-center mt-2">

            <?php
           if(!empty($user_name)){
              
            echo "<h4>".$user_name.'</h4>';
            echo "<p class='font-weight-normal  mb-1'>".$_SESSION['my_email']."</p>";
            }
            ?> 
          </div>
      </div>
      <p class="text-gray font-weight-bold text-uppercase px-3 small pb-4 mb-0">Dashboard <span style="width:100%;background: #ccc;
     height: 2px; border:1px solid blaack;margin-top:10px; display: block; "></span></p>

      <ul class="nav flex-column  mb-0">
        
            <li class="nav-item">
                 <a href="index.php" class="nav-link text-dark "> <i class="fa fa-home "></i>&nbsp;Home</a>
              </li>
              <li class="nav-item">
                 <a href="investment.php" class="nav-link text-dark "> <i class="fas fa-university"></i>&nbsp;Investments</a>
              </li>
            <li class="nav-item">
                 <a href="payment.php" class="nav-link text-dark"> <i class="fas fa-money-bill-wave"></i>&nbsp;Payments</a>
              </li>
              <li class="nav-item">
                 <a href="withdraws.php" class="nav-link text-dark "> <i class="fa fa-download "></i> &nbsp;Withdraws</a>
              </li>
              <li class="nav-item">
                 <a href="affiliate.php" class="nav-link text-dark"> <i class="fas fa-sync"></i>&nbsp;Affilates</a>
              </li>
              <li class="nav-item">
                 <a href="userprofile.php" class="nav-link text-dark"> <i class="fa fa-sign-out-alt"></i>&nbsp;Settings</a>
              </li>
              <li class="nav-item">
                 <a href="support.php" class="nav-link text-dark"> <i class="fa fa-support"></i>&nbsp;Support</a>
              </li>
              <li class="nav-item">
                 <a href="login.php" class="nav-link text-dark"> <i class="fa fa-sign-out-alt " name="logout"></i> &nbsp;Logout</a>
              </li>
      </ul>
    </div>
