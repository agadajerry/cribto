 <?php  include ('config/registers_data.php');

if(!isset($_SESSION["my_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
  </head>
  <body>
    
    <!-- vertical menu -->

   <?php include 'header.php'?>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5 pt-5 page-content">
        <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
        <h2 class="mb-4">Dashboard&nbsp;<a href="" data-toggle="modal" style="border-radius: 50%; width:50px;"
                   data-target="#staticBackdrop"><i class="fa fa-info " ></i></a></h2>
      <div class="progress mb-2">
          <div class="progress-bar" role="progressbar" style="width: <?php echo (14.29*$days).'%';?>;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?php echo 'Day '.$days."  ( ".(14.29*$days).'% )';?></div>
    </div>

        <!-- cards hold menu information -->
      <div class="row">
      <div class="col-md-3">
        <div class="card">
          <div class="card-body first-card-bg">
            <?php if (isset($_SESSION['my_name'])):?>
              <h3 class="card-title"><?php echo '$'. number_format(($bonusAmount+$earning)); ?></h3>
            <?php endif;?>
            <p class="card-text">Account balance</p>
            <a href="make_withdraw.php" class="btn btn-primary">Withdraw</a>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <div class="card-body second-card-bg">
            <h3 class="card-title">$<?php echo $_SESSION['amount'];?></h3>
            <p class="card-text">Investment</p>
            <a href="investment.php" class="btn btn-primary">More Info</a>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <div class="card-body third-card-bg">
            <h3 class="card-title"><?php echo '$'. number_format($earning); ?></h3>
            <p class="card-text">Earnings</p>
            <a href="payment.php" class="btn btn-primary">More info</a>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <div class="card-body fourth-card-bg">
            <h5 class="card-title">$0</h5>
            <p class="card-text">Withdraws</p>
            <a href="withdraws.php" class="btn btn-primary">More info</a>
          </div>
        </div>
      </div>
    </div>
    <!-- end of cards -->

    <!-- investment selection section -->

    <h2 class="mb-4 mt-3">Invest</h2>
          
            <!-- cards hold menu information -->
            <!-- cards hold menu information -->
      <div class="row">

      <!-- get plan from database, investmentplan -->
    

            <?php  if (isset($_SESSION['my_name'])):?>
            
              
           <?php   $result = selectAllPlan();?>

          <?php  if (mysqli_num_rows($result)>0):?>

           <?php while ($row = mysqli_fetch_array($result)):?>

            <div class="col-md-4 shadow p-3 mb-5 bg-white rounded">
            <div class="card ">
              <div class="card-header" style="background:#ad08f8; color:#fff;">
                <h3 class="text-center"><?php echo $row['plan_name'];?></h3>
                <h1 class="text-center"><?php echo $row['return_percent']; ?>%</h1>
              </div>
              <ul class="list-group list-group-flush">
                <li class="list-group-item"><?php echo 'Daily for ' .$row['duration'].' Days'; ?></li>
                <li class="list-group-item"><?php echo 'Total Profit '.$row['return_percent']*$row['duration'].'%'; ?></li>
                <li class="list-group-item"><?php echo 'Minimum Deposit ' .$row['min_deposit'].'$'; ?></li>
                <li class="list-group-item"><?php echo 'Maximum Deposit ' .$row['max_deposit'].'$'; ?></li>
              </ul>
                </div>
                <div class="card-body">
                  <a href="investment_address.php?get_invest_info=<?php echo $row['id']?>" class="btn btn-primary text-center" style="width:100%">Invest</a>
          </div>
              </div>
        
                
        
    
      <?php endwhile;?>
        <?php endif;?>
        <?php endif;?>
    </div>
   <!-- end of content container-->

       <!-- modal body for notification -->
    
    <div class="modal fade" id="staticBackdrop" data-backdrop="static">
    <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Notification</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

      <small>No information yet</small>

      </div>
    </div>
  </div>
</div>
 </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
  </body>
</html>