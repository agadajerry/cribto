
<?php include ('config/registers_data.php')?>

<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/index.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body style="background:gray;">
    

       <!-- registration form start from here -->
       <div class="container mt-5">
       
         <div class="row">
           <div  class="col-md-4"></div>

            <div  class="col-md-4 mt-3">
              <div class="card shadow-sm p-3 mb-5 bg-white rounded mt-3">
                <div class="card-body">
                   <div style="text-align:center;">
                    <h5 style="margin-top: 10px;"><img src="images/logo.png" id="logo"></h5>
                    </div>
                    <?php 

                    if (isset($_SESSION['email_exist'])) {
                      $class = "alert alert-danger alert-dismissible fade show";
                      $role ="alert";
                     echo "<div role= '$role' class='$class' id ='alert-dismissible'>". $_SESSION['email_exist'];
                     echo "<button type='button' class='btn-close' id='warningbtn' data-bs-dismiss='alert' aria-label='Close'></button>";
                     echo "</div>";
                      

                     // unset($_SESSION['email_exist']);
                    }
                    ?>
                 
                  <div class="card-title text-center py-3"><h5>Register A New Account</h5></div>
                 </div>
              <form method="post" id="form">
                <div class="input-group has-validation mb-3">
                <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-user"></i></span>
                  <input type="text" class="form-control" id="fullname" aria-describedby="fullname" placeholder="Full Name" name="fullname">
                </div>
                <div class="input-group has-validation mb-3">
                  <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-envelope"></i></span>
                  <input type="email" class="form-control" id="email" aria-describedby="email" placeholder="Email address" name="email">
                </div>
                  <div class="input-group has-validation mb-3">
                  <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-key"></i></span>
                  <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                  </div>
                  <div class="input-group has-validation mb-3">
                  <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-repeat"></i></span>
                  <input type="password" class="form-control" id="repeat_password" placeholder="Repeat Password- Greater than 3" name="rpassword">
                  </div>
                  <div class="input-group has-validation mb-3">
                    <span class="input-group-text" id="inputGroupPrepend"><i class="fas fa-user-plus"></i></span>
                  <input type="referral_code" class="form-control" id="referral_code" placeholder="Referral code(Optional)" name="referral_code">
                  </div>
                  <div class="mb-3 regbtn">
                  <button type="submit" class="btn btn-primary mb-2" name="submit" id="regBtn">Register</button>
                </div>
                <div class="account_already">
                  <a href="index.php"><img src="images/back.png"></a>
                  <a href="login.php" style="text-decoration: none;">Already have an account?</a>
                </div>
              </form>
            </div>
             <div  class="col-md-4"></div>
         </div>
       </div>
     </div>
   </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/main.js"></script>
    <script src="script2/data_table.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script >
      
       $(document).ready(function(){

      $('#warningbtn').on('click',function(){
     $('#alert-dismissible').hide();
  })
       })


    </script>

    <script>
      //check whether the enter password match

        let regBtn = document.getElementById('regBtn');
         let fullname = document.getElementById('fullname');
        let pass1 = document.getElementById('password');
        let pass2 = document.getElementById('repeat_password');
         let alertDiv =  document.getElementById('alert');

        regBtn.onclick = function(){
         if (pass1.value!=pass2.value) {
            return false;
         }else if(pass1.value.length<=3 && pass2.value.length<=3 && fullname.value.length<=3){
         
          return false;
         }
        }

    </script>
  </body>
</html>