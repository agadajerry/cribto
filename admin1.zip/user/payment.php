<?php  include ('config/registers_data.php');

if(!isset($_SESSION["my_name"]))
{
 header("location:login.php");
}
?> 
<!doctype html>
<html lang="en">
  <head>
    <title>Bullish Assets -BTC Investment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="script2/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="font/all.css">
    <link rel="stylesheet" type="text/css" href="script2/main.css">
    <link rel="stylesheet" type="text/css" href="script2/data_table.css">
  </head>
  <body>
    
    <!-- vertical menu -->

    <?php include 'header.php'?>


        <!-- Page Content  -->
     <div id="content" class="p-4 p-md-5 pt-5 page-content">
       <div class="custom-menu">
      <button type="button" id="sidebarCollapse" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4">
           <i class="fa fa-bars"></i>
          </button>
        </div>
        <!-- body of content -->
        <h2 class="mb-4">Payments</h2>
  

         <!-- table of payment -->
  <div class="row">
    <div class="col-md-12">
  <table class="table mt-4 table-striped" id="payment_table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Date</th>
      <th scope="col">Amount</th>
      <th scope="col">Plan</th>
      <th scope="col"> Hash</th>
      <th scope="col">Status</th>
       <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <tr>
       <?php

            if (isset($_SESSION['my_email'])) {
              
              $id =0;
              $result = select_payment();

              if (mysqli_num_rows($result)>0) {
    
            while ($row = mysqli_fetch_array($result)){
              $id++;
              echo "<td>".$id."</td>";
              echo "<td>".$row['date']."</td>";
              echo "<td>".$row['amount']."</td>";
              echo "<td>".$row['plan']."</td>";
              echo "<td>".$row['hash']."</td>";
              echo "<td style='color:green;background:#fff; font-weight:600; '>".$row['status']."</td>";
              echo "<td><a href=investment_address.php class='btn btn-danger'>Pay</a>'</td>";
              echo "</tr>";
            }
            }else{
              echo "<td> Table is empty</td>";
            }
            }

          ?>
    </tr>
  </tbody>
</table>
</div>
</div>
       
 </div>
    <script src="script2/jQuery.js"></script>
    <script src="script2/popper.min.js"></script>
    <script src="script2/bootstrap.min.js"></script>
    <script src="script2/data_table.js"></script>
    <script src="script2/main.js"></script>
    <script>
      $(document).ready(function() {
    $('#payment_table').DataTable();
} );
    </script>
  </body>
</html>